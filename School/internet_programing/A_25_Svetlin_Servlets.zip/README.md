INSTALLATION

- Download apache tomcat server version 7
- Import the project
- Locate "servlet-api.jar" file in the "lib" folder and add that to the imported project's build path
- Add tomcat as a server
- Run

I hope i haven't forgotten a step.